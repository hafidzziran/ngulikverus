{
  "hash": "f6707721907d93b40ed17327986380315ddd1e5ba02ed663595ba2fee0b7a55e",
  "signature": "AdJ+NQABQSCfhDH38vrW2KGsal24Qg3IYfFbWXJJJFSkrS2cCxovv1tPbm1BCEMQSBCMnTjtNMwsdKLwbPBurf8kmiRxX9K+",
  "signer": "Verus Coin Foundation Releases@"
}
