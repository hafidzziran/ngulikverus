
VerusCoin Command Line Tools v1.2.9-5

Contents:
verusd - VerusCoin daemon
verus - VerusCoin command line utility

The first time on a new system you will need to run ./fetch-params before using verusd.

Run:
./verusd to launch the VerusCoin daemon
Use verus to run commands such as:
./verus stop
Which signals verusd (if it is running) to stop running.

